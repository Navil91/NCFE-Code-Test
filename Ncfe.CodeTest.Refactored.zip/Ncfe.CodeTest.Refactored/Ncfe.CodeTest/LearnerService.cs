using Ncfe.CodeTest.Models;
using Ncfe.CodeTest.Services;

namespace Ncfe.CodeTest
{
    public class LearnerService
    {
        private readonly IArchivedDataService _archivedDataService;
        private readonly ILearnerDataAccess _learnerDataAccess;
        private readonly FailoverService _failoverService;

        public LearnerService(
            IArchivedDataService archivedDataService,
            ILearnerDataAccess learnerDataAccess,
            FailoverService failoverService)
        {
            _archivedDataService = archivedDataService;
            _learnerDataAccess = learnerDataAccess;
            _failoverService = failoverService;
        }

        public Learner GetLearner(int learnerId, bool isLearnerArchived)
        {
            if (isLearnerArchived)
            {
                return _archivedDataService.GetArchivedLearner(learnerId);
            }

            LearnerResponse learnerResponse;
            if (_failoverService.IsInFailoverMode())
            {
                learnerResponse = _failoverService.GetLearnerResponse(learnerId);
            }
            else
            {
                learnerResponse = _learnerDataAccess.LoadLearner(learnerId);
            }

            return learnerResponse.IsArchived 
                ? _archivedDataService.GetArchivedLearner(learnerId) 
                : learnerResponse.Learner;
        }
    }
}
