using Ncfe.CodeTest.Models;

namespace Ncfe.CodeTest.Services
{
    public class LearnerDataAccess : ILearnerDataAccess
    {
        public LearnerResponse LoadLearner(int learnerId)
        {
            
            return new LearnerResponse();
        }
    }
}
