using Ncfe.CodeTest.Models;

namespace Ncfe.CodeTest.Services
{
    public class ArchivedDataService : IArchivedDataService
    {
        public Learner GetArchivedLearner(int learnerId)
        {
            
            return new Learner();
        }
    }
}
