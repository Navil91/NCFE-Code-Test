using System.Collections.Generic;
using Ncfe.CodeTest.Models;

namespace Ncfe.CodeTest.Services
{
    public class FailoverRepository : IFailoverRepository
    {
        public IEnumerable<FailoverEntry> GetFailOverEntries()
        {
           
            return new List<FailoverEntry>();
        }
    }
}
