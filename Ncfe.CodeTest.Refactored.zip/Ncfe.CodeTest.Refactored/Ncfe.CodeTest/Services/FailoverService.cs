using System;
using System.Linq;
using Ncfe.CodeTest.Models;

namespace Ncfe.CodeTest.Services
{
    public class FailoverService
    {
        private readonly IFailoverRepository _failoverRepository;
        private readonly ILearnerDataAccess _failoverDataAccess;
        private const int FailoverThreshold = 100;

        public FailoverService(IFailoverRepository failoverRepository, ILearnerDataAccess failoverDataAccess)
        {
            _failoverRepository = failoverRepository;
            _failoverDataAccess = failoverDataAccess;
        }

        public bool IsInFailoverMode()
        {
            var failoverEntries = _failoverRepository.GetFailOverEntries();
            var recentFailures = failoverEntries.Count(fe => fe.DateTime > DateTime.Now.AddMinutes(-10));
            return recentFailures > FailoverThreshold;
        }

        public LearnerResponse GetLearnerResponse(int learnerId)
        {
            return _failoverDataAccess.LoadLearner(learnerId);
        }
    }
}
