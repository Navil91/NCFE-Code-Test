using Moq;
using Xunit;
using Ncfe.CodeTest;
using Ncfe.CodeTest.Services;
using Ncfe.CodeTest.Models;

namespace Ncfe.CodeTest.Tests
{
    public class LearnerServiceTests
    {
        private readonly Mock<IArchivedDataService> _archivedDataServiceMock;
        private readonly Mock<ILearnerDataAccess> _learnerDataAccessMock;
        private readonly Mock<IFailoverRepository> _failoverRepositoryMock;
        private readonly LearnerService _learnerService;
        private readonly FailoverService _failoverService;

        public LearnerServiceTests()
        {
            _archivedDataServiceMock = new Mock<IArchivedDataService>();
            _learnerDataAccessMock = new Mock<ILearnerDataAccess>();
            _failoverRepositoryMock = new Mock<IFailoverRepository>();
            _failoverService = new FailoverService(_failoverRepositoryMock.Object, _learnerDataAccessMock.Object);
            _learnerService = new LearnerService(
                _archivedDataServiceMock.Object, 
                _learnerDataAccessMock.Object, 
                _failoverService);
        }

        [Fact]
        public void GetLearner_ShouldReturnArchivedLearner_WhenIsLearnerArchivedIsTrue()
        {
            // Arrange
            var learnerId = 1;
            var expectedLearner = new Learner();
            _archivedDataServiceMock.Setup(s => s.GetArchivedLearner(learnerId)).Returns(expectedLearner);

            // Act
            var result = _learnerService.GetLearner(learnerId, true);

            // Assert
            Assert.Equal(expectedLearner, result);
        }

        [Fact]
        public void GetLearner_ShouldReturnLearnerFromFailover_WhenInFailoverMode()
        {
            // Arrange
            var learnerId = 1;
            var expectedLearnerResponse = new LearnerResponse { Learner = new Learner() };
            _failoverRepositoryMock.Setup(r => r.GetFailOverEntries()).Returns(new List<FailoverEntry>
            {
                new FailoverEntry { DateTime = DateTime.Now.AddMinutes(-5) }
            });
            _learnerDataAccessMock.Setup(d => d.LoadLearner(learnerId)).Returns(expectedLearnerResponse);

            // Act
            var result = _learnerService.GetLearner(learnerId, false);

            // Assert
            Assert.Equal(expectedLearnerResponse.Learner, result);
        }

        [Fact]
        public void GetLearner_ShouldReturnLearnerFromMainDataStore_WhenNotInFailoverMode()
        {
            // Arrange
            var learnerId = 1;
            var expectedLearnerResponse = new LearnerResponse { Learner = new Learner() };
            _failoverRepositoryMock.Setup(r => r.GetFailOverEntries()).Returns(new List<FailoverEntry>()); // No failures
            _learnerDataAccessMock.Setup(d => d.LoadLearner(learnerId)).Returns(expectedLearnerResponse);

            // Act
            var result = _learnerService.GetLearner(learnerId, false);

            // Assert
            Assert.Equal(expectedLearnerResponse.Learner, result);
        }
    }
}
