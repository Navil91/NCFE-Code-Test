namespace Ncfe.CodeTest.Models
{
    public class LearnerResponse
    {
        public bool IsArchived { get; set; }
        public Learner Learner { get; set; }
        // Additional properties as needed
    }
}
