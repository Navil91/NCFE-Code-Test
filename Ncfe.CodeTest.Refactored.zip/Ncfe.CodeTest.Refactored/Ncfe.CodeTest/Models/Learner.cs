namespace Ncfe.CodeTest.Models
{
    public class Learner
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public DateTime EnrollmentDate { get; set; }
        // Additional properties as needed
    }
}
