namespace Ncfe.CodeTest.Models
{
    public class FailoverEntry
    {
        public DateTime DateTime { get; set; }
        // Additional properties as needed
    }
}
