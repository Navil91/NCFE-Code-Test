using Ncfe.CodeTest.Models;

namespace Ncfe.CodeTest
{
    public interface IArchivedDataService
    {
        Learner GetArchivedLearner(int learnerId);
    }
}
