using System.Collections.Generic;
using Ncfe.CodeTest.Models;

namespace Ncfe.CodeTest
{
    public interface IFailoverRepository
    {
        IEnumerable<FailoverEntry> GetFailOverEntries();
    }
}
