## Overview

This project is a refactored version of the `LearnerService` class in a codebase designed to manage and retrieve learner data. The refactoring was performed to improve code maintainability, adhere to SOLID principles, and ensure robust testing. The system retrieves learner data from multiple sources, including a primary data store, an archived data store, and a failover data store, depending on the current state of the system.

## Features

- **Failover Mechanism**: The system evaluates if it should switch to a failover data store based on the number of failed requests within a 10-minute window.
- **Archived Data Handling**: Learners marked as archived are retrieved from a dedicated archive store.
- **SOLID Principles**: The code adheres to SOLID principles, improving maintainability, testability, and flexibility.
- **Unit Testing**: Comprehensive unit tests validate the behavior of the `GetLearner` method under different conditions.

## Project Structure

```
Ncfe.CodeTest/
│
├── Interfaces/
│   ├── IArchivedDataService.cs
│   ├── ILearnerDataAccess.cs
│   └── IFailoverRepository.cs
│
├── Models/
│   ├── Learner.cs
│   ├── LearnerResponse.cs
│   └── FailoverEntry.cs
│
├── Services/
│   ├── ArchivedDataService.cs
│   ├── LearnerDataAccess.cs
│   ├── FailoverRepository.cs
│   ├── FailoverService.cs
│   └── LearnerService.cs
│
├── Tests/
│   └── LearnerServiceTests.cs
│
└── Ncfe.CodeTest.csproj
```

## Installation

### Prerequisites

- [.NET SDK 8.0](https://dotnet.microsoft.com/download/dotnet/8.0) or later
- A code editor or IDE, such as [Visual Studio Code](https://code.visualstudio.com/) or [Rider](https://www.jetbrains.com/rider/)

### Steps

1. **Clone the repository**:
   ```sh
   git clone <repository-url>
   ```
   Replace `<repository-url>` with the URL of your repository.

2. **Navigate to the project directory**:
   ```sh
   cd Ncfe.CodeTest
   ```

3. **Restore the dependencies**:
   ```sh
   dotnet restore
   ```

## Running the Project

### Running Unit Tests

To ensure that the code works as expected, you can run the unit tests provided:

```sh
dotnet test
```

This command will run all the tests in the `Tests` directory and display the results in the terminal.

### Running the Application

If the application has an executable component (e.g., a console application), you can run it using:

```sh
dotnet run
```

### Packaging for Deployment

To package the project for deployment or distribution, you can use the following command:

```sh
dotnet publish -c Release -o ./publish
```

This will compile the project and place the output in the `publish` directory.

## Usage

The `LearnerService` class provides a method `GetLearner` that retrieves learner data based on the provided parameters:

- **`learnerId`**: The ID of the learner to retrieve.
- **`isLearnerArchived`**: A boolean indicating whether to retrieve the learner from the archived data store.

### Example Usage

```csharp
var learnerService = new LearnerService(
    archivedDataService: new ArchivedDataService(),
    learnerDataAccess: new LearnerDataAccess(),
    failoverService: new FailoverService(
        failoverRepository: new FailoverRepository(),
        failoverDataAccess: new LearnerDataAccess()
    )
);

var learner = learnerService.GetLearner(learnerId: 1, isLearnerArchived: false);
```

## Key Considerations

- **Failover Logic**: The system will switch to a failover data store if the number of failed requests in the last 10 minutes exceeds a predefined threshold.
- **Test Coverage**: Unit tests are provided to ensure the correctness of the `GetLearner` method under various scenarios.

## Further Improvements

- **Logging**: Implement logging to monitor the failover process and other critical operations.
- **Configuration**: Make the failover threshold and time window configurable.
- **Error Handling**: Enhance error handling to cover edge cases and unexpected failures.
---

This README provides an overview of the refactored code, instructions for running and testing the project, and guidance on how to extend it further.

/**
 * @author ${Navil91}
 */